class linear_exp:
    def __init__(self,n):
        self.n = list(n)

    def __repr__(self):
        return "Linear Equation" + str(self.n)
    def __str__ (self):
        def power(p):
            if p == 0:
                equation= ""
            if p == 1:
                equation = "x"
            if p > 1:
                equation = "x^%ds" %p
        p = len(self.n) - 1
        equation = ""

        for i in range(0,p):
            n = self.n[i]
            if n == 1 and i < p :
                equation += power(p-i)
            elif n != 0:
                equation += n + power(p-i)
        return '+'.join(equation)
    def __add__(self, other):
        return linear_exp(self.n + other.n)

    def multiple(self,c):
        return linear_exp(self.n * c.n)
